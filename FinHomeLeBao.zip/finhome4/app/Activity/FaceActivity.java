package com.datn.finhome.Views.Activity;

import android.app.Activity;

public class FaceActivity extends Activity {
}
