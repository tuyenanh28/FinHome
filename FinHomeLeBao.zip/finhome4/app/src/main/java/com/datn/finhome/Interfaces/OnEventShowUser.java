package com.datn.finhome.Interfaces;


import com.datn.finhome.Models.UserCategory;
import com.datn.finhome.Models.UserModel;

public interface OnEventShowUser {
    void onClickShowUser(UserModel user);
}
