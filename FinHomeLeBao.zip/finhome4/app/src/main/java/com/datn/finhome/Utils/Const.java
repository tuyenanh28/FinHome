package com.datn.finhome.Utils;

public class Const {
    public static String HOST_FIREBASE = "Host";
    public static String ROOM_FIREBASE = "Room";

}
