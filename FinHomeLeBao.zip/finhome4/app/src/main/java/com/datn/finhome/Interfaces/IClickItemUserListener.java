package com.datn.finhome.Interfaces;

import com.datn.finhome.Models.RoomModel;

public interface IClickItemUserListener {
    void onClickItemRoom(RoomModel roomModel);
}
