package com.datn.finhome.Models;

public class photoViewPage {
    private int resourceId;


    public photoViewPage(int resourceId) {
        this.resourceId = resourceId;
    }

    public int getResourceId() {
        return resourceId;
    }

    public void setResourceId(int resourceId) {
        this.resourceId = resourceId;
    }
}
